package com.electropi;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import static org.junit.jupiter.api.Assertions.assertTrue;

class InventoryTest {
  @Test void storeAdminCreatesProduct() {
    String base = System.getenv("BASE_URL"), email = System.getenv("ADMIN_EMAIL"),
           password = System.getenv("ADMIN_PASSWORD");
    if (base == null || email == null || password == null)
      throw new IllegalStateException("Set BASE_URL, ADMIN_EMAIL, ADMIN_PASSWORD");
    WebDriver driver = new ChromeDriver();
    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
    try {
      driver.get(base + "/login");
      wait.until(d -> d.findElement(By.cssSelector("input[name='email']"))).sendKeys(email);
      driver.findElement(By.cssSelector("input[name='password']")).sendKeys(password);
      driver.findElement(By.xpath("//button[normalize-space()='Log in']")).click();
      wait.until(d -> d.findElement(By.xpath("//a[normalize-space()='Inventory']"))).click();
      wait.until(d -> d.findElement(By.xpath("//button[normalize-space()='Add Product']"))).click();
      wait.until(d -> d.findElement(By.cssSelector("input[name='productName']")))
          .sendKeys("Wireless Mouse " + System.currentTimeMillis());
      driver.findElement(By.cssSelector("input[name='price']")).sendKeys("25.00");
      driver.findElement(By.xpath("//button[normalize-space()='Save']")).click();
      assertTrue(wait.until(d -> {
        WebElement toast = d.findElement(By.cssSelector("[role='status']"));
        return toast.isDisplayed() && toast.getText().matches("(?i).*product.*(created|saved).*");
      }));
    } finally { driver.quit(); }
  }
}
