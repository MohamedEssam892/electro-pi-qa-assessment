# Electro Pi QA assessment

Companion implementation for the three PDF answers. Part 1 uses Selenium and Java. The application, selectors, authentication contract, and database schema were not supplied. Adapt the selectors and routes to the actual application before execution; no live system was tested.

## UI (Selenium and Java)

Install Java 17, Maven, and Chrome. From `java/`, run:
`BASE_URL=https://your-app.example ADMIN_EMAIL=... ADMIN_PASSWORD=... mvn test`.

## API

The Postman collection uses environment variables `baseUrl`, `token`, and `sku`. Configure the collection's auth request URL and response token field to match the actual auth contract, or supply a short-lived token in the environment. Never commit credentials. Run `npm run test:api` after setting environment values.

The PDFs are the submission answers; code is illustrative until integrated with the real platform.
